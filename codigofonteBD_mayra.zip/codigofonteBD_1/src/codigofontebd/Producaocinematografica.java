
package codigofontebd;

public class Producaocinematografica {
    private String nome;
    private String genero;
    
    public Producaocinematografica(){
        this.nome = "";
        this.genero = "";
    }
    public Producaocinematografica(String nome, String genero) {
        this.nome = nome;
        this.genero = genero;
    }

    public String getTelefone() {
        return nome;
    }

    public void setTelefone(String telefone) {
        this.nome = nome;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String email) {
        this.genero = email;
    }

    public String getNome() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setNome(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}

