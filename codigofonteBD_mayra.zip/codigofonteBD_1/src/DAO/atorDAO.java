
package DAO;

import codigofontebd.Ator;
import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class atorDAO {
    public void inserirAtor (Ator a){
        try {
            String SQL = "INSERT INTO mayra_barbosa.ator1(telefone, email, CPF) VALUES (?,?,?)";
            Connection minhaConexao = conexao.getConexao();
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            comando.setString(1, a.getTelefone());
            comando.setString(2, a.getEmail());
            comando.setString(3, a.getCPF());
            int retorno = comando.executeUpdate();
            if(retorno>0){
                JOptionPane.showMessageDialog(null, "Email " +a.getEmail()+ " cadastrado com sucesso." );
            }
            else{
                JOptionPane.showMessageDialog(null, "Erro ao cadastrar o email " +a.getEmail()+ ", verifique seus dados.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(atorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private Ator pegaDados(ResultSet resultado){
        try {
            Ator atual=new Ator();
            atual.setEmail(resultado.getString("email"));
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(atorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}


