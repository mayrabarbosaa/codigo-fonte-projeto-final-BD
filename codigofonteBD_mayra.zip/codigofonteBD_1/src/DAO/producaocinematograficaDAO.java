
package DAO;
import codigofontebd.Producaocinematografica;
import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class producaocinematograficaDAO {
    public void inserirProducaocinematografica (Producaocinematografica p){
        try {
            String SQL = "INSERT INTO mayra_barbosa.producaocinematograficaa(nome, genero) VALUES (?,?,?)";
            Connection minhaConexao = conexao.getConexao();
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            comando.setString(1, p.getNome());
            comando.setString(2, p.getGenero());
            int retorno = comando.executeUpdate();
            if(retorno>0){
                JOptionPane.showMessageDialog(null, "Email " +p.getNome()+ " cadastrado com sucesso." );
            }
            else{
                JOptionPane.showMessageDialog(null, "Erro ao cadastrar o email " +p.getNome()+ ", verifique seus dados.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(producaocinematograficaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private Producaocinematografica pegaDados(ResultSet resultado){
        try {
            Producaocinematografica atual=new Producaocinematografica();
            atual.setNome(resultado.getString ("nome"));
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(producaocinematograficaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
