
package DAO;
import codigofontebd.Funcionarioproducao;
import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class funcionarioproducaoDAO {
    public void inserirFuncionarioproducao (Funcionarioproducao f){
        try {
            String SQL = "INSERT INTO mayra_barbosa.funcionariodaproducaoo(telefone, email, CPF) VALUES (?,?,?)";
            Connection minhaConexao = conexao.getConexao();
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            comando.setString(1, f.getTelefone());
            comando.setString(2, f.getEmail());
            comando.setString(3, f.getCPF());
            int retorno = comando.executeUpdate();
            if(retorno>0){
                JOptionPane.showMessageDialog(null, "Email " +f.getEmail()+ " cadastrado com sucesso." );
            }
            else{
                JOptionPane.showMessageDialog(null, "Erro ao cadastrar o email " +f.getEmail()+ ", verifique seus dados.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(funcionarioproducaoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private Funcionarioproducao pegaDados(ResultSet resultado){
        try {
            Funcionarioproducao atual=new Funcionarioproducao();
            atual.setEmail(resultado.getString("email"));
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(funcionarioproducaoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}


