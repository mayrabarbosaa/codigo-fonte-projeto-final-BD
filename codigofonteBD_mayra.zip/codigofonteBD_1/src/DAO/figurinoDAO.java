
package DAO;

import codigofontebd.Figurino;
import conexao.conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class figurinoDAO {
    public void inserirFigurino (Figurino f){
        try {
            String SQL = "INSERT INTO mayra_barbosa.figurino1(Categoria, Numero de serie) VALUES (?,?,?)";
            Connection minhaConexao = conexao.getConexao();
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            comando.setString(1, f.getCategoria());
            comando.setInt(2, f.getNserie());
            int retorno = comando.executeUpdate();
            if(retorno>0){
                JOptionPane.showMessageDialog(null, "Figurino" +f.getNserie()+ " cadastrado com sucesso." );
            }
            else{
                JOptionPane.showMessageDialog(null, "Erro ao cadastrar figurino" +f.getNserie()+ " , verifique os LOGS.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(figurinoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private Figurino pegaDados(ResultSet resultado){
        try {
            Figurino atual=new Figurino();
            atual.setNserie(resultado.getInt ("Numero de serie"));
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(figurinoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}


